example project to transform two CSVs into a single SQL table
